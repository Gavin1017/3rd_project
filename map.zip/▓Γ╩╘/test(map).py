import pygame

# 初始化 Pygame
pygame.init()

# 设置屏幕尺寸
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))

# 设置颜色
black = (0, 0, 0)
white = (255, 255, 255)

# 设置字体和大小
font = pygame.font.SysFont(None, 36)

# 想要显示的文本
full_text = 'ahkdf bkbksjkfb jbksf djksnkjf nkj fslkafnl n'

# 设置每行的最大像素宽度
max_line_width = 200

# 分割文本到多行
words = full_text.split(' ')
lines = []
current_line = ''
for word in words:
    # 如果加上新单词后超过了最大宽度，则当前行结束，开始新行
    if font.size(current_line + word)[0] > max_line_width:
        lines.append(current_line.strip())
        current_line = word + ' '
    else:
        current_line += word + ' '
lines.append(current_line.strip())  # 添加最后一行

# 渲染每一行文本，并将其绘制到屏幕上
y = 10  # 初始y坐标
for line in lines:
    text_surface = font.render(line, True, white)
    text_rect = text_surface.get_rect(x=screen_width - max_line_width - 10, y=y)
    screen.blit(text_surface, text_rect)
    y += text_rect.height  # 更新y坐标，为下一行腾出空间

# 更新屏幕显示
pygame.display.flip()

# 退出Pygame的正确方法
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

pygame.quit()
